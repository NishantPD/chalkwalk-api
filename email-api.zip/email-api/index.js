const express = require('express');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3001;

app.use(bodyParser.json());

// Configure your email transport
const transporter = nodemailer.createTransport({
  service: 'gmail', // or another email provider
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

app.post('/send-entry', async (req, res) => {
  const { subject, text, to } = req.body;
  console.log('Received /send-entry request:', { subject, text, to });
  try {
    const info = await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: to || process.env.EMAIL_TO, // fallback to default
      subject: subject || 'New Form Entry',
      text: text,
    });
    console.log('Email sent:', info.response);
    res.status(200).json({ message: 'Email sent' });
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Email API listening at http://localhost:${port}`);
});
